import json
import os
import ssl
import requests
from typing import Dict, Any, Optional
from datetime import datetime

import pg8000

def lambda_handler(event, context):
    """
    Lambda function for Harmonic AI company enrichment
    Expects: POST request with company identifier (website_url, etc.)
    Returns: Enriched company data
    """
    
    # Log the incoming event for debugging
    print(f"Harmonic Enrichment Lambda invoked with event: {json.dumps(event)[:500]}...")
    
    # CORS headers for all responses
    cors_headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
    }
    
    # Handle CORS preflight requests
    http_method = event.get('httpMethod') or event.get('requestContext', {}).get('http', {}).get('method')
    if http_method == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': cors_headers,
            'body': json.dumps({'message': 'CORS preflight OK'})
        }
    
    # Parse the request
    try:
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event.get('body', {})
            
        # Handle direct Lambda invoke (no HTTP wrapper)
        if not body and any(key in event for key in ['website_url', 'company_id']):
            body = event
            
        print(f"Parsed request body: {json.dumps(body)}")
        
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}")
        return {
            'statusCode': 400,
            'headers': cors_headers,
            'body': json.dumps({'error': 'Invalid JSON in request body'})
        }
    
    # Validate required fields
    company_id = body.get('company_id')
    if not company_id:
        return {
            'statusCode': 400,
            'headers': cors_headers,
            'body': json.dumps({'error': 'company_id is required'})
        }
    
    # Get the identifier for Harmonic API
    identifier_key = None
    identifier_value = None
    
    # Priority order for identifiers
    identifier_fields = [
        'website_url', 'website_domain', 'linkedin_url', 'crunchbase_url',
        'pitchbook_url', 'twitter_url', 'instagram_url', 'facebook_url',
        'angellist_url', 'monster_url', 'indeed_url', 'stackoverflow_url'
    ]
    
    for field in identifier_fields:
        if body.get(field):
            identifier_key = field
            identifier_value = body[field]
            break
    
    if not identifier_key or not identifier_value:
        return {
            'statusCode': 400,
            'headers': cors_headers,
            'body': json.dumps({'error': 'At least one company identifier is required (website_url, linkedin_url, etc.)'})
        }
    
    try:
        # Call Harmonic AI API for enrichment
        enrichment_result = enrich_company_with_harmonic(identifier_key, identifier_value)
        
        if enrichment_result.get('error'):
            return {
                'statusCode': 400,
                'headers': cors_headers,
                'body': json.dumps({'error': enrichment_result['error']})
            }
        
        # Save enriched data to database
        save_result = save_enrichment_to_database(company_id, enrichment_result)
        
        if save_result.get('error'):
            # Still return the enrichment data even if save fails
            print(f"Warning: Failed to save enrichment to database: {save_result['error']}")
        
        return {
            'statusCode': 200,
            'headers': cors_headers,
            'body': json.dumps({
                'success': True,
                'data': {
                    'enrichment': enrichment_result,
                    'saved_to_db': not bool(save_result.get('error')),
                    'company_id': company_id
                }
            })
        }
        
    except Exception as e:
        print(f"Unexpected error in enrichment: {e}")
        import traceback
        traceback.print_exc()
        
        return {
            'statusCode': 500,
            'headers': cors_headers,
            'body': json.dumps({'error': f'Internal server error: {str(e)}'})
        }


def enrich_company_with_harmonic(identifier_key: str, identifier_value: str) -> Dict[str, Any]:
    """
    Call Harmonic AI API to enrich company data
    """
    try:
        # Get Harmonic API key from environment
        api_key = os.environ.get('HARMONIC_API_KEY')
        if not api_key:
            return {'error': 'Harmonic API key not configured'}
        
        # Prepare the API request
        url = 'https://api.harmonic.ai/companies'
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        
        # Build request body with the identifier
        request_body = {identifier_key: identifier_value}
        
        print(f"Calling Harmonic API with: {request_body}")
        
        # Make the API call
        response = requests.post(url, headers=headers, json=request_body, timeout=30)
        
        print(f"Harmonic API response status: {response.status_code}")
        print(f"Harmonic API response body: {response.text}")
        
        if response.status_code == 404:
            # Company not found or enrichment in progress
            response_data = response.json()
            enrichment_id = response_data.get('enrichment_id')
            
            if enrichment_id:
                return {
                    'status': 'enrichment_in_progress',
                    'enrichment_id': enrichment_id,
                    'message': 'Company enrichment is in progress. Check back in a couple hours.',
                    'estimated_completion': 'In 2-4 hours'
                }
            else:
                return {'error': 'Company not found in Harmonic database'}
        
        if response.status_code != 200:
            return {'error': f'Harmonic API error: {response.status_code} - {response.text}'}
        
        # Parse and return the enriched data
        enriched_data = response.json()
        
        # Extract key fields for easier frontend consumption
        extracted_data = extract_key_enrichment_fields(enriched_data)
        
        return {
            'status': 'success',
            'raw_data': enriched_data,
            'extracted': extracted_data,
            'enriched_at': datetime.utcnow().isoformat()
        }
        
    except requests.RequestException as e:
        print(f"Request error: {e}")
        return {'error': f'Failed to connect to Harmonic API: {str(e)}'}
    except Exception as e:
        print(f"Unexpected error in Harmonic API call: {e}")
        return {'error': f'Harmonic enrichment failed: {str(e)}'}


def extract_key_enrichment_fields(harmonic_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract and format key fields from Harmonic response for frontend display
    """
    try:
        extracted = {}
        
        # Basic company info
        extracted['name'] = harmonic_data.get('name')
        extracted['legal_name'] = harmonic_data.get('legal_name')
        extracted['description'] = harmonic_data.get('description')
        extracted['short_description'] = harmonic_data.get('short_description')
        extracted['external_description'] = harmonic_data.get('external_description')
        
        # Company details
        extracted['headcount'] = harmonic_data.get('headcount')
        extracted['stage'] = harmonic_data.get('stage')
        extracted['customer_type'] = harmonic_data.get('customer_type')
        extracted['company_type'] = harmonic_data.get('company_type')
        extracted['ownership_status'] = harmonic_data.get('ownership_status')
        extracted['logo_url'] = harmonic_data.get('logo_url')
        
        # Founding information
        founding_date = harmonic_data.get('founding_date')
        if founding_date:
            extracted['founding_date'] = founding_date.get('year') if isinstance(founding_date, dict) else founding_date
        
        # Location
        location = harmonic_data.get('location')
        if location:
            extracted['location'] = {
                'city': location.get('city'),
                'state': location.get('state'),
                'country': location.get('country'),
                'display': f"{location.get('city', '')}, {location.get('state', '')} {location.get('country', '')}".strip(', ')
            }
        
        # Contact info
        contact = harmonic_data.get('contact')
        if contact:
            extracted['contact'] = {
                'email': contact.get('email'),
                'phone': contact.get('phone')
            }
        
        # Website
        website = harmonic_data.get('website')
        if website:
            extracted['website'] = {
                'url': website.get('url'),
                'domain': website.get('domain')
            }
        
        # Social media
        socials = harmonic_data.get('socials')
        if socials:
            extracted['socials'] = {
                'linkedin': socials.get('linkedin_url'),
                'twitter': socials.get('twitter_url'),
                'facebook': socials.get('facebook_url'),
                'instagram': socials.get('instagram_url')
            }
        
        # Funding information
        funding = harmonic_data.get('funding')
        if funding:
            extracted['funding'] = {
                'total_funding': funding.get('funding_total'),
                'last_funding_date': funding.get('last_funding_date'),
                'funding_stage': funding.get('funding_stage'),
                'valuation': funding.get('valuation')
            }
        
        # Key people (CEO and executives)
        people = harmonic_data.get('people', [])
        if people:
            extracted['people'] = []
            ceo_found = False
            
            for person in people[:10]:  # Limit to first 10 people
                person_data = {
                    'name': person.get('name'),
                    'title': person.get('title'),
                    'linkedin_url': person.get('linkedin_url')
                }
                
                # Check if this is the CEO
                title = (person.get('title') or '').lower()
                if 'ceo' in title or 'chief executive' in title:
                    extracted['ceo'] = person_data
                    ceo_found = True
                
                # Add to general people list if executive level
                if any(keyword in title for keyword in ['ceo', 'cto', 'cfo', 'chief', 'president', 'founder', 'co-founder']):
                    extracted['people'].append(person_data)
        
        # Company highlights
        highlights = harmonic_data.get('highlights', [])
        if highlights:
            extracted['highlights'] = highlights[:5]  # Limit to top 5 highlights
        
        # Tags for categorization
        tags = harmonic_data.get('tags', [])
        tags_v2 = harmonic_data.get('tags_v2', [])
        if tags or tags_v2:
            extracted['tags'] = list(set(tags + tags_v2))[:10]  # Combine and limit tags
        
        # Traction metrics
        traction_metrics = harmonic_data.get('traction_metrics', [])
        if traction_metrics:
            extracted['traction_metrics'] = traction_metrics[:5]  # Limit to top 5 metrics
        
        return extracted
        
    except Exception as e:
        print(f"Error extracting enrichment fields: {e}")
        return {'error': f'Failed to extract enrichment data: {str(e)}'}


def save_enrichment_to_database(company_id: str, enrichment_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Save enriched company data to the database
    """
    try:
        # Database configuration
        db_config = {
            'host': os.environ.get('DB_HOST'),
            'port': int(os.environ.get('DB_PORT', '5432')),
            'database': os.environ.get('DB_NAME'),
            'user': os.environ.get('DB_USER'),
            'password': os.environ.get('DB_PASSWORD'),
        }
        
        # Connect to database
        ssl_context = ssl.create_default_context()
        conn = pg8000.connect(**db_config, ssl_context=ssl_context, timeout=30)
        cursor = conn.cursor()
        
        # Create enrichment table if it doesn't exist
        create_table_sql = """
        CREATE TABLE IF NOT EXISTS company_enrichments (
            id SERIAL PRIMARY KEY,
            company_id INTEGER NOT NULL REFERENCES companies(id),
            harmonic_entity_urn VARCHAR(255),
            harmonic_data JSONB NOT NULL,
            extracted_data JSONB,
            enrichment_status VARCHAR(50) DEFAULT 'success',
            enriched_at TIMESTAMP DEFAULT NOW(),
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
        );
        
        CREATE INDEX IF NOT EXISTS idx_company_enrichments_company_id ON company_enrichments(company_id);
        CREATE INDEX IF NOT EXISTS idx_company_enrichments_status ON company_enrichments(enrichment_status);
        """
        
        cursor.execute(create_table_sql)
        
        # Insert or update enrichment data
        harmonic_urn = enrichment_data.get('raw_data', {}).get('entity_urn')
        
        upsert_sql = """
        INSERT INTO company_enrichments (
            company_id, harmonic_entity_urn, harmonic_data, extracted_data, 
            enrichment_status, enriched_at, updated_at
        ) VALUES (%s, %s, %s, %s, %s, %s, NOW())
        ON CONFLICT (company_id) 
        DO UPDATE SET 
            harmonic_entity_urn = EXCLUDED.harmonic_entity_urn,
            harmonic_data = EXCLUDED.harmonic_data,
            extracted_data = EXCLUDED.extracted_data,
            enrichment_status = EXCLUDED.enrichment_status,
            enriched_at = EXCLUDED.enriched_at,
            updated_at = NOW()
        RETURNING id;
        """
        
        cursor.execute(upsert_sql, [
            int(company_id),
            harmonic_urn,
            json.dumps(enrichment_data.get('raw_data', {})),
            json.dumps(enrichment_data.get('extracted', {})),
            enrichment_data.get('status', 'success'),
            enrichment_data.get('enriched_at')
        ])
        
        enrichment_id = cursor.fetchone()[0]
        
        # Commit the transaction
        conn.commit()
        cursor.close()
        conn.close()
        
        return {
            'success': True,
            'enrichment_id': enrichment_id,
            'company_id': company_id
        }
        
    except Exception as e:
        print(f"Database save error: {e}")
        import traceback
        traceback.print_exc()
        return {'error': f'Failed to save enrichment to database: {str(e)}'}


def get_company_enrichment(company_id: str) -> Dict[str, Any]:
    """
    Retrieve existing enrichment data for a company
    """
    try:
        # Database configuration
        db_config = {
            'host': os.environ.get('DB_HOST'),
            'port': int(os.environ.get('DB_PORT', '5432')),
            'database': os.environ.get('DB_NAME'),
            'user': os.environ.get('DB_USER'),
            'password': os.environ.get('DB_PASSWORD'),
        }
        
        # Connect to database
        ssl_context = ssl.create_default_context()
        conn = pg8000.connect(**db_config, ssl_context=ssl_context, timeout=30)
        cursor = conn.cursor()
        
        # Query for existing enrichment
        query_sql = """
        SELECT harmonic_data, extracted_data, enrichment_status, enriched_at
        FROM company_enrichments 
        WHERE company_id = %s 
        ORDER BY enriched_at DESC 
        LIMIT 1;
        """
        
        cursor.execute(query_sql, [int(company_id)])
        result = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if result:
            return {
                'success': True,
                'data': {
                    'harmonic_data': result[0],
                    'extracted_data': result[1],
                    'status': result[2],
                    'enriched_at': result[3].isoformat() if result[3] else None
                }
            }
        else:
            return {'success': True, 'data': None}
            
    except Exception as e:
        print(f"Database query error: {e}")
        return {'error': f'Failed to retrieve enrichment data: {str(e)}'}